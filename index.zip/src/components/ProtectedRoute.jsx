import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export const ProtectedRoute = () => {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <p className="text-gray-600">Checking permissions...</p>
      </div>
    );
  }

  // If not logged in, go to login
  if (!user) {
    return <Navigate to="/login" replace />;
  }

  // If logged in, but lacks the "family" role, block access or show unauthorized
  if (!user.roles.includes('family')) {
    return (
      <div className="flex h-screen flex-col items-center justify-center bg-gray-50 text-center">
        <h1 className="text-2xl font-bold text-red-600">Access Denied</h1>
        <p className="mt-2 text-gray-600">You need the <span className="font-semibold text-gray-800">family</span> role to view these expenses.</p>
        <a href="/.auth/logout" className="mt-4 rounded bg-gray-800 px-4 py-2 text-sm text-white hover:bg-gray-700">
          Sign out and switch accounts
        </a>
      </div>
    );
  }

  return <Outlet />;
};
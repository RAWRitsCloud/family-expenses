import React from 'react';
import { useAuth } from '../context/AuthContext';

export default function Login() {
  const { login } = useAuth();

  return (
    <div className="flex h-screen items-center justify-center bg-gray-100">
      <div className="w-full max-w-sm rounded-lg bg-white p-8 shadow-md text-center">
        <h2 className="mb-2 text-2xl font-bold text-gray-800">Family Expenses</h2>
        <p className="mb-6 text-sm text-gray-500">Please sign in with your authorized account</p>
        
        <div className="space-y-3">
          <button
            onClick={() => login('github')}
            className="w-full rounded bg-gray-900 py-2 text-white font-semibold hover:bg-gray-800 transition-colors"
          >
            Sign in with GitHub
          </button>
          
          <button
            onClick={() => login('aad')}
            className="w-full rounded bg-blue-600 py-2 text-white font-semibold hover:bg-blue-700 transition-colors"
          >
            Sign in with Microsoft
          </button>
        </div>
      </div>
    </div>
  );
}